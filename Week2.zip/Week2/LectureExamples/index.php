<?php
// $name = 'Jake';
// echo "Hello World $name";

// $array = array();
// $array[0] = 1;
// $array[1] = 2;

// $array[] = 10;
// echo $array[2];

// $arraySize = count($array);
// echo "<br> Array size = $arraySize";

// Loop Challenge

// Getting Key and Value
// $array = array();
// $array['username'] = 's111111';
// $array['password'] = 'jake';

// foreach ($array as $key => $value) {
//     echo "$key => $value <br>";
// }

// Get Value not the key

$array = array();
$array['username'] = 's111111';
$array['password'] = 'jake';

foreach ($array as $value) {
    echo "$value <br>";
}

?>